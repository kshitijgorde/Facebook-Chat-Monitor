<?php

print_r($_GET["hub_challenge"]);


