<?php
// parameters
//curl -ik -X POST "https://graph.facebook.com/v2.6/me/subscribed_apps?access_token=<token>
$hubVerifyToken = 'VERIFY_TOKEN';
$requestmethod = 'PUT';
$accessToken = "EAACzgsivPIwBAP6yxh0hGZClr4CjQHmcrCbqn7wlCTByNumcx3G54axIPO0uua6MU2ZB2w4KQq48Is5U4kQCqcfURf572XwFq9CYoCYE6OSumqTZAFmBuxYS0wesl6XQtKyoN3BpDEqECNuMNT0vKGXnWjON7AzTdZAQNYLfAQZDZD";

// check token at setup


if ($_SERVER['REQUEST_METHOD'] === $requestmethod)
{
    $f = @fopen("facebookmsg.txt", "w");
   
   
    if ($f !== false) {
        ftruncate($f,0);
    fclose($f);
       }
    
}
if ($_REQUEST['hub_verify_token'] === $hubVerifyToken) {
  echo $_REQUEST['hub_challenge'];
  exit;
}

else{
    $input = json_decode(file_get_contents('php://input'), true);
    echo $input;
    $senderId = $input['entry'][0]['messaging'][0]['sender']['id'];
    $messageText = $input['entry'][0]['messaging'][0]['message']['text'];
    
    $myfile = file_put_contents('facebookmsg.txt', $messageText.PHP_EOL , FILE_APPEND | LOCK_EX);
    $ch = curl_init();

// set URL and other appropriate options
    //curl_setopt($ch, CURLOPT_URL, "https://pisp-chat-monitor-blitzkshitij.c9users.io/forscript.html");
    //curl_setopt($ch, CURLOPT_HEADER, 0);

// grab URL and pass it to the browser
    //curl_exec($ch);

// close cURL resource, and free up system resources
    //curl_close($ch);
    //if($messageText == "hi") {
    //    $answer = "Hello";
    //}
    
    //$response = [
     //   'recipient' => [ 'id' => $senderId ],
      //  'message' => [ 'text' => $answer ]
    //];
    //$ch = curl_init('https://graph.facebook.com/v2.6/me/messages?access_token='.$accessToken);
    //curl_setopt($ch, CURLOPT_POST, 1);
    //curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($response));
    //curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    //if(!empty($input['entry'][0]['messaging'][0]['message'])){
    //curl_exec($ch);
}

  ?>
  